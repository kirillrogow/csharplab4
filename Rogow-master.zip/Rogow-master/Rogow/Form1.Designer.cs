﻿namespace Rogow
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.HookToogler = new System.Windows.Forms.Button();
            this.LogToFile = new System.Windows.Forms.CheckBox();
            this.History = new System.Windows.Forms.TextBox();
            this.SuppressKeyPress = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // HookToogler
            // 
            this.HookToogler.Location = new System.Drawing.Point(12, 12);
            this.HookToogler.Name = "HookToogler";
            this.HookToogler.Size = new System.Drawing.Size(75, 23);
            this.HookToogler.TabIndex = 0;
            this.HookToogler.Text = "Включить";
            this.HookToogler.UseVisualStyleBackColor = true;
            this.HookToogler.Click += new System.EventHandler(this.HookToogler_Click);
            // 
            // LogToFile
            // 
            this.LogToFile.AutoSize = true;
            this.LogToFile.Location = new System.Drawing.Point(93, 16);
            this.LogToFile.Name = "LogToFile";
            this.LogToFile.Size = new System.Drawing.Size(97, 17);
            this.LogToFile.TabIndex = 2;
            this.LogToFile.Text = "Вывод в файл";
            this.LogToFile.UseVisualStyleBackColor = true;
            // 
            // History
            // 
            this.History.Location = new System.Drawing.Point(12, 41);
            this.History.Multiline = true;
            this.History.Name = "History";
            this.History.Size = new System.Drawing.Size(296, 208);
            this.History.TabIndex = 3;
            // 
            // SuppressKeyPress
            // 
            this.SuppressKeyPress.AutoSize = true;
            this.SuppressKeyPress.Location = new System.Drawing.Point(187, 16);
            this.SuppressKeyPress.Name = "SuppressKeyPress";
            this.SuppressKeyPress.Size = new System.Drawing.Size(111, 17);
            this.SuppressKeyPress.TabIndex = 4;
            this.SuppressKeyPress.Text = "Отмена нажатия";
            this.SuppressKeyPress.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(320, 261);
            this.Controls.Add(this.SuppressKeyPress);
            this.Controls.Add(this.History);
            this.Controls.Add(this.LogToFile);
            this.Controls.Add(this.HookToogler);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button HookToogler;
        private System.Windows.Forms.CheckBox LogToFile;
        private System.Windows.Forms.TextBox History;
        private System.Windows.Forms.CheckBox SuppressKeyPress;
    }
}

