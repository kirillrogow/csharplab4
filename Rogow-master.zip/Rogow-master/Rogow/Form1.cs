﻿using Gma.System.MouseKeyHook;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rogow
{
    public partial class Form1 : Form
    {
        private const int MaxLines = 20;

        private IKeyboardMouseEvents globalHook;

        private static bool HookEnabled = false;
        private static FileStream logFile = File.OpenWrite("Keylog.txt");
        private static StreamWriter sw = new StreamWriter(logFile);
        private static List<string> history = new List<string>(MaxLines);
        public Form1()
        {
            InitializeComponent();
        }

        private void HookToogler_Click(object sender, EventArgs e)
        {
            HookEnabled = !HookEnabled;
            if (HookEnabled)
            {
                ((Button)sender).Text = "Выключить";
            }
            else
            {
                ((Button)sender).Text = "Включить";
            }
        }
        private void OnKeyDown(object sender, KeyEventArgs e)
        {
            if (HookEnabled)
            {
                var str = e.KeyCode.ToString();
                if (LogToFile.Checked)
                {
                    sw.Write(str);
                }
                while (history.Count >= MaxLines)
                {
                    history.RemoveAt(0);
                }
                history.Add(str);
                History.Text = string.Join("\r\n", history.ToArray());
                e.SuppressKeyPress = SuppressKeyPress.Checked;
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            globalHook = Hook.GlobalEvents();
            globalHook.KeyDown += OnKeyDown;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            globalHook.KeyDown -= OnKeyDown;
            globalHook.Dispose();
            sw.Dispose();
            logFile.Dispose();
        }
    }
}
